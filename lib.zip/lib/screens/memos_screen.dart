import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/storage_service.dart';

// ============================================================
// ПАМЯТКИ
// ============================================================
// Весь раздел памяток живёт здесь вместе со своим состоянием.
// main.dart только показывает этот экран.

class MemosScreen extends StatefulWidget {
  MemosScreen({super.key});

  @override
  State<MemosScreen> createState() => _MemosScreenState();
}

class _MemosScreenState extends State<MemosScreen> {
  /// Какая фракция сейчас открыта в разделе «Памятки».
  /// null = показываем список всех фракций.
  String? _selectedMemoFaction;
  /// Какой отдел сейчас открыт внутри выбранной фракции.
  /// null = показываем список отделов.
  String? _selectedMemoDepartment;

  /// Какой пункт памятки сейчас открыт внутри отдела.
  /// null = показываем список пунктов отдела.
  String? _selectedMemoItem;
  /// Нужно ли сейчас подтверждение очистки недельного отчёта.
bool _weeklyReportClearConfirm = false;
  /// Данные для недельного отчёта Управления кадров.
final TextEditingController _weeklyReportTagController =
    TextEditingController();

final TextEditingController _weeklyReportDateFromController =
    TextEditingController();

final TextEditingController _weeklyReportDateToController =
    TextEditingController();
    final List<TextEditingController> _weeklyReportAcceptedControllers = [
  TextEditingController(),
];
  final List<TextEditingController> _weeklyReportDismissedControllers = [
  TextEditingController(),
];

final List<TextEditingController> _weeklyReportPromotedControllers = [
  TextEditingController(),
];

final List<TextEditingController> _weeklyReportGovWaveControllers = [
  TextEditingController(),
];

final List<TextEditingController> _weeklyReportExamsControllers = [
  TextEditingController(),
];

  @override
  void initState() {
    super.initState();
    _loadWeeklyReport();
  }

/// СОХРАНЯЕТ ТЕКУЩИЙ НЕДЕЛЬНЫЙ ОТЧЁТ.
Future<void> _saveWeeklyReport() async {
  List<String> values(
    List<TextEditingController> controllers,
  ) {
    return controllers
        .map((controller) => controller.text)
        .toList();
  }

  await StorageService.saveWeeklyReport(
    tag: _weeklyReportTagController.text,
    dateFrom: _weeklyReportDateFromController.text,
    dateTo: _weeklyReportDateToController.text,
    accepted: values(_weeklyReportAcceptedControllers),
    dismissed: values(_weeklyReportDismissedControllers),
    promoted: values(_weeklyReportPromotedControllers),
    govWave: values(_weeklyReportGovWaveControllers),
    exams: values(_weeklyReportExamsControllers),
  );
}
// ==========================================================
// НЕДЕЛЬНЫЙ ОТЧЁТ — ПОЛНАЯ ОЧИСТКА
// ==========================================================

/// Полностью очищает недельный отчёт и сохраняет пустое состояние.
Future<void> _clearWeeklyReport() async {
  _weeklyReportTagController.clear();
  _weeklyReportDateFromController.clear();
  _weeklyReportDateToController.clear();

  void resetControllers(
    List<TextEditingController> controllers,
  ) {
    for (final controller in controllers) {
      controller.dispose();
    }

    controllers
      ..clear()
      ..add(
        TextEditingController(),
      );
  }

  resetControllers(
    _weeklyReportAcceptedControllers,
  );

  resetControllers(
    _weeklyReportDismissedControllers,
  );

  resetControllers(
    _weeklyReportPromotedControllers,
  );

  resetControllers(
    _weeklyReportGovWaveControllers,
  );

  resetControllers(
    _weeklyReportExamsControllers,
  );

  await _saveWeeklyReport();

  if (!mounted) return;

  setState(() {});
}

  @override
  void dispose() {
    _weeklyReportTagController.dispose();
    _weeklyReportDateFromController.dispose();
    _weeklyReportDateToController.dispose();

    for (final controller in _weeklyReportAcceptedControllers) {
      controller.dispose();
    }
    for (final controller in _weeklyReportDismissedControllers) {
      controller.dispose();
    }
    for (final controller in _weeklyReportPromotedControllers) {
      controller.dispose();
    }
    for (final controller in _weeklyReportGovWaveControllers) {
      controller.dispose();
    }
    for (final controller in _weeklyReportExamsControllers) {
      controller.dispose();
    }

    super.dispose();
  }

/// ЗАГРУЖАЕТ СОХРАНЁННЫЙ НЕДЕЛЬНЫЙ ОТЧЁТ ПРИ СТАРТЕ.
Future<void> _loadWeeklyReport() async {
  final data = await StorageService.loadWeeklyReport();

  _weeklyReportTagController.text =
      data['tag'] as String;

  _weeklyReportDateFromController.text =
      data['dateFrom'] as String;

  _weeklyReportDateToController.text =
      data['dateTo'] as String;

  void restoreControllers(
    List<TextEditingController> controllers,
    List<String> savedValues,
  ) {
    for (final controller in controllers) {
      controller.dispose();
    }

    controllers
      ..clear()
      ..addAll(
        savedValues.isEmpty
            ? [TextEditingController()]
            : savedValues.map(
                (value) => TextEditingController(text: value),
              ),
      );
  }

  restoreControllers(
    _weeklyReportAcceptedControllers,
    List<String>.from(data['accepted'] as List),
  );

  restoreControllers(
    _weeklyReportDismissedControllers,
    List<String>.from(data['dismissed'] as List),
  );

  restoreControllers(
    _weeklyReportPromotedControllers,
    List<String>.from(data['promoted'] as List),
  );

  restoreControllers(
    _weeklyReportGovWaveControllers,
    List<String>.from(data['govWave'] as List),
  );

  restoreControllers(
    _weeklyReportExamsControllers,
    List<String>.from(data['exams'] as List),
  );

  if (!mounted) return;

  setState(() {});
}

  /// ОДНА КАРТОЧКА ФРАКЦИИ В РАЗДЕЛЕ «ПАМЯТКИ».
  Widget _buildMemoFactionTile({
    required IconData icon,
    required String title,
  }) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 6,
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
        side: BorderSide(
          color: Colors.white24,
        ),
      ),
      leading: Icon(icon),
      title: Text(
        title,
        style: TextStyle(
          fontWeight: FontWeight.w600,
        ),
      ),
      trailing: Icon(Icons.chevron_right),
      onTap: () {
        setState(() {
          _selectedMemoFaction = title;
          _selectedMemoDepartment = null;
          _selectedMemoItem = null;
        });
      },
    );
  }

  /// ОДНА КАРТОЧКА ОТДЕЛА В РАЗДЕЛЕ «ПАМЯТКИ».
  Widget _buildMemoDepartmentTile({
    required IconData icon,
    required String title,
  }) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 6,
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
        side: BorderSide(
          color: Colors.white24,
        ),
      ),
      leading: Icon(icon),
      title: Text(
        title,
        style: TextStyle(
          fontWeight: FontWeight.w600,
        ),
      ),
      trailing: Icon(Icons.chevron_right),
      onTap: () {
        setState(() {
          _selectedMemoDepartment = title;
          _selectedMemoItem = null;
        });
      },
    );
  }
// ==========================================================
// ПАМЯТКИ — КЛИКАБЕЛЬНЫЕ ССЫЛКИ
// ==========================================================

/// Открывает ссылку во внешнем приложении / браузере.
// ==========================================================
// ПАМЯТКИ — ОТКРЫТИЕ DISCORD-СРЫЛОК В ПРИЛОЖЕНИИ
// ==========================================================

/// Если это Discord-ссылка — пытаемся открыть её прямо в Discord.
/// Если Discord не установлен / deep link не сработал — открываем браузер.
Future<void> _openMemoLink(String url) async {
  final webUri = Uri.parse(url);

  if (url.contains('discord.com/channels/')) {
    final discordUrl = url.replaceFirst(
      'https://discord.com',
      'discord://-',
    );

    final discordUri = Uri.parse(discordUrl);

    final openedInDiscord = await launchUrl(
      discordUri,
      mode: LaunchMode.externalApplication,
    );

    if (openedInDiscord) {
      return;
    }
  }

  await launchUrl(
    webUri,
    mode: LaunchMode.externalApplication,
  );
}

/// Рисует кликабельную ссылку внутри памятки.
Widget _buildMemoLink({
  required String title,
  required String url,
}) {
  return InkWell(
    onTap: () {
      _openMemoLink(url);
    },
    borderRadius: BorderRadius.circular(8),
    child: Padding(
      padding: const EdgeInsets.symmetric(
        vertical: 7,
        horizontal: 4,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.link,
            size: 18,
            color: Colors.lightBlueAccent,
          ),

          SizedBox(width: 8),

          Expanded(
            child: Text(
              title,
              style: TextStyle(
                fontSize: 15,
                color: Colors.lightBlueAccent,
                decoration: TextDecoration.underline,
                decorationColor: Colors.lightBlueAccent,
              ),
            ),
          ),
        ],
      ),
    ),
  );
}
  /// ОДНА КАРТОЧКА ПУНКТА ВНУТРИ ОТДЕЛА.
  Widget _buildMemoItemTile({
    required IconData icon,
    required String title,
  }) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 6,
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
        side: BorderSide(
          color: Colors.white24,
        ),
      ),
      leading: Icon(icon),
      title: Text(
        title,
        style: TextStyle(
          fontWeight: FontWeight.w600,
        ),
      ),
      trailing: Icon(Icons.chevron_right),
      onTap: () {
        setState(() {
          _selectedMemoItem = title;
        });
      },
    );
  }
  /// СОБИРАЕТ ВЕСЬ НЕДЕЛЬНЫЙ ОТЧЁТ В ГОТОВЫЙ ТЕКСТ.
String _buildWeeklyReportText() {
  List<String> links(List<TextEditingController> controllers) {
    return controllers
        .map((controller) => controller.text.trim())
        .where((text) => text.isNotEmpty)
        .toList();
  }

  final accepted = links(_weeklyReportAcceptedControllers);
  final dismissed = links(_weeklyReportDismissedControllers);
  final promoted = links(_weeklyReportPromotedControllers);
  final govWave = links(_weeklyReportGovWaveControllers);
  final exams = links(_weeklyReportExamsControllers);

  return [
    _weeklyReportTagController.text.trim(),
    '',
    'Недельный отчёт за период с '
        '${_weeklyReportDateFromController.text.trim()} '
        'по ${_weeklyReportDateToController.text.trim()}',
    '',
    'Проделанная работа:',
    '',
    'Принято [${accepted.length}] человек:',
    ...accepted,
    '',
    'Уволено [${dismissed.length}] человек:',
    ...dismissed,
    '',
    'Повышено [${promoted.length}] человек:',
    ...promoted,
    '',
    'Подача гос.волны [${govWave.length}]:',
    ...govWave,
    '',
    'Принято экзаменов [${exams.length}]:',
    ...exams,
  ].join('\n');
}
/// УНИВЕРСАЛЬНЫЙ БЛОК ССЫЛОК ДЛЯ НЕДЕЛЬНОГО ОТЧЁТА.
///
/// Сам считает количество непустых строк.
/// Кнопка "+" добавляет новую строку.
/// Корзина удаляет ненужную строку.
Widget _buildWeeklyReportLinksBlock({
  required String title,
  required String suffix,
  required List<TextEditingController> controllers,
}) {
  final filledCount = controllers
      .where((controller) => controller.text.trim().isNotEmpty)
      .length;

  return Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      border: Border.all(
        color: Colors.white24,
      ),
      borderRadius: BorderRadius.circular(10),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          '$title [$filledCount] $suffix',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w700,
          ),
        ),

        SizedBox(height: 12),
        // ==========================================================
        // НЕДЕЛЬНЫЙ ОТЧЁТ — СТРОКИ ССЫЛОК
        // ==========================================================

        for (int i = 0; i < controllers.length; i++) ...[
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: controllers[i],
                  onChanged: (_) {
  setState(() {});

  // Автосохраняем отчёт при изменении ссылки.
  _saveWeeklyReport();
},
                  decoration: InputDecoration(
                    hintText: 'Ссылка ${i + 1}',
                    filled: true,
                    fillColor: Colors.white.withValues(alpha: 0.05),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),

              SizedBox(width: 8),

              IconButton(
                tooltip: 'Удалить строку',
               onPressed: controllers.length == 1
    ? null
    : () {
        setState(() {
          controllers[i].dispose();
          controllers.removeAt(i);
        });

        // Автосохраняем отчёт после удаления строки.
        _saveWeeklyReport();
      },
                icon: Icon(
                  Icons.delete_outline,
                ),
              ),
            ],
          ),

          SizedBox(height: 8),
        ],

        Align(
          alignment: Alignment.centerLeft,
          child: TextButton.icon(
            onPressed: () {
  setState(() {
    controllers.add(
      TextEditingController(),
    );
  });

  // Автосохраняем отчёт после добавления новой строки.
  _saveWeeklyReport();
},
            icon: Icon(
              Icons.add,
              size: 18,
            ),
            label: Text(
              'Добавить ссылку',
            ),
          ),
        ),
      ],
    ),
  );
}
  /// КАЛЬКУЛЯТОР НЕДЕЛЬНОГО ОТЧЁТА УПРАВЛЕНИЯ КАДРОВ.
  Widget _buildWeeklyReportCalculator() {
    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton.icon(
            onPressed: () {
              setState(() {
                _selectedMemoItem = null;
              });
            },
            icon: Icon(
              Icons.arrow_back,
              size: 18,
            ),
            label: Text(
              'Назад к памяткам отдела',
            ),
          ),
        ),

        SizedBox(height: 8),

        Text(
          'Калькулятор недельного отчёта',
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.w700,
          ),
        ),

        SizedBox(height: 8),

        Text(
          'Управление кадров · Правительство',
          style: TextStyle(
            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.54),
            fontSize: 14,
          ),
        ),

        SizedBox(height: 20),

        TextField(
  controller: _weeklyReportTagController,
  onChanged: (_) {
  _saveWeeklyReport();
},
  decoration: InputDecoration(
    labelText: 'Тэг себя',
    hintText: '@твой_тэг',
    filled: true,
    fillColor: Colors.white.withValues(alpha: 0.05),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: BorderSide.none,
    ),
  ),
),

SizedBox(height: 16),

Row(
  children: [
    Expanded(
      child: TextField(
        controller: _weeklyReportDateFromController,
        onChanged: (_) {
  _saveWeeklyReport();
},
        decoration: InputDecoration(
          labelText: 'Дата с',
          hintText: '01.01.2001',
          filled: true,
          fillColor: Colors.white.withValues(alpha: 0.05),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    ),

    SizedBox(width: 12),

    Expanded(
      child: TextField(
        controller: _weeklyReportDateToController,
        onChanged: (_) {
  _saveWeeklyReport();
},
        decoration: InputDecoration(
          labelText: 'Дата по',
          hintText: '07.01.2001',
          filled: true,
          fillColor: Colors.white.withValues(alpha: 0.05),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    ),
  ],
),
SizedBox(height: 24),

_buildWeeklyReportLinksBlock(
  title: 'Принято',
  suffix: 'человек',
  controllers: _weeklyReportAcceptedControllers,
),
SizedBox(height: 16),

_buildWeeklyReportLinksBlock(
  title: 'Уволено',
  suffix: 'человек',
  controllers: _weeklyReportDismissedControllers,
),

SizedBox(height: 16),

_buildWeeklyReportLinksBlock(
  title: 'Повышено',
  suffix: 'человек',
  controllers: _weeklyReportPromotedControllers,
),

SizedBox(height: 16),

_buildWeeklyReportLinksBlock(
  title: 'Подача гос.волны',
  suffix: '',
  controllers: _weeklyReportGovWaveControllers,
),

SizedBox(height: 16),

_buildWeeklyReportLinksBlock(
  title: 'Принято экзаменов',
  suffix: '',
  controllers: _weeklyReportExamsControllers,
),
SizedBox(height: 24),

SizedBox(
  height: 48,
  child: ElevatedButton.icon(
    onPressed: () async {
      final reportText = _buildWeeklyReportText();

      await Clipboard.setData(
        ClipboardData(
          text: reportText,
        ),
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Недельный отчёт скопирован',
          ),
          duration: Duration(seconds: 2),
        ),
      );
    },
    icon: Icon(
      Icons.copy,
      size: 18,
    ),
    label: Text(
      'Скопировать отчёт',
    ),
  ),
),
SizedBox(height: 12),

if (!_weeklyReportClearConfirm)
  SizedBox(
    height: 48,
    child: OutlinedButton.icon(
      onPressed: () {
        setState(() {
          _weeklyReportClearConfirm = true;
        });
      },
      icon: Icon(
        Icons.delete_outline,
        size: 18,
      ),
      label: Text(
        'Очистить отчёт',
      ),
    ),
  )
else
  Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      border: Border.all(
        color: Colors.white24,
      ),
      borderRadius: BorderRadius.circular(10),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          'Точно очистить отчёт?',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w700,
          ),
        ),

        SizedBox(height: 6),

        Text(
          'Будут удалены даты, тэг и все ссылки.',
          style: TextStyle(
            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.54),
            fontSize: 13,
          ),
        ),

        SizedBox(height: 12),

        Row(
          children: [
            Expanded(
              child: OutlinedButton(
                onPressed: () {
                  setState(() {
                    _weeklyReportClearConfirm = false;
                  });
                },
                child: Text(
                  'Отмена',
                ),
              ),
            ),

            SizedBox(width: 10),

            Expanded(
              child: ElevatedButton(
                onPressed: () async {
                  await _clearWeeklyReport();

                  if (!mounted) return;

                  setState(() {
                    _weeklyReportClearConfirm = false;
                  });

                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        'Недельный отчёт очищен',
                      ),
                      duration: Duration(seconds: 2),
                    ),
                  );
                },
                child: Text(
                  'Да, очистить',
                ),
              ),
            ),
          ],
        ),
      ],
    ),
  ),
      ],
    );
  }

  /// ЭТА СТРАНИЦА ОТВЕЧАЕТ ЗА ПАМЯТКИ:
  /// фракция -> отдел -> пункт памятки.
  Widget _buildMemosPage() {
    
    // Калькулятор недельного отчёта — отдельная страница.
    if (_selectedMemoFaction == 'Правительство' &&
        _selectedMemoDepartment == 'Управление кадров' &&
        _selectedMemoItem == 'Калькулятор недельного отчёта') {
      return _buildWeeklyReportCalculator();
    }
if (_selectedMemoFaction == 'Правительство' &&
    _selectedMemoDepartment == 'Управление кадров' &&
    _selectedMemoItem == 'Обязанности отдела') {
  return ListView(
    padding: const EdgeInsets.all(24),
    children: [
      Align(
        alignment: Alignment.centerLeft,
        child: TextButton.icon(
          onPressed: () {
            setState(() {
              _selectedMemoItem = null;
            });
          },
          icon: Icon(
            Icons.arrow_back,
            size: 18,
          ),
          label: Text(
            'Назад к памяткам отдела',
          ),
        ),
      ),

      SizedBox(height: 8),

      Text(
        'Обязанности отдела',
        style: TextStyle(
          fontSize: 28,
          fontWeight: FontWeight.w700,
        ),
      ),

      SizedBox(height: 8),

      Text(
        'Управление кадров · Правительство',
        style: TextStyle(
          color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.54),
          fontSize: 14,
        ),
      ),

      SizedBox(height: 20),

      Column(
  crossAxisAlignment: CrossAxisAlignment.start,
  children: [
    Text(
      'ОБЯЗАННОСТИ ОТДЕЛА',
      style: TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.w800,
      ),
    ),

    SizedBox(height: 16),

    Text(
      'Проверять каналы:',
      style: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
      ),
    ),

    SizedBox(height: 8),

    _buildMemoLink(
      title: '🔓・выдача-ролей',
      url: 'https://discord.com/channels/1538939600549191830/1538939603606573070',
    ),

    _buildMemoLink(
      title: '📑・кадровый-аудит',
      url: 'https://discord.com/channels/1538939600549191830/1538939604168867901',
    ),

    _buildMemoLink(
      title: '・заявки-на-увал',
      url: 'https://discord.com/channels/1538939600549191830/1540120233614901280',
    ),

    SizedBox(height: 16),

    Text(
      'На обращения, требующие реакции, необходимо отвечать.',
      style: TextStyle(
        fontSize: 15,
        height: 1.5,
        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
      ),
    ),

    SizedBox(height: 22),

    Text(
      '🔓・выдача-ролей',
      style: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
      ),
    ),

    SizedBox(height: 6),

    SelectableText(
      'Во время набора каждому сотруднику, принятому в организацию, '
      'необходимо выдать соответствующие роли — Правительство, Академия ФСО.',
      style: TextStyle(
        fontSize: 15,
        height: 1.5,
        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
      ),
    ),

    SizedBox(height: 22),

    Text(
      '📑・кадровый-аудит',
      style: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
      ),
    ),

    SizedBox(height: 6),

    SelectableText(
      'Все кадровые действия в отношении сотрудников должны фиксироваться '
      'в кадровом аудите.',
      style: TextStyle(
        fontSize: 15,
        height: 1.5,
        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
      ),
    ),

    SizedBox(height: 10),

    SelectableText(
      '• Повышение\n'
      '• Понижение\n'
      '• Выдача выговора\n'
      '• Снятие выговора\n'
      '• Принятие\n'
      '• Увольнение',
      style: TextStyle(
        fontSize: 15,
        height: 1.6,
        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
      ),
    ),

    SizedBox(height: 10),

    Text(
      'Все действия производятся через бота, путём вызова команды:',
      style: TextStyle(
        fontSize: 15,
        height: 1.5,
        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
      ),
    ),

    SizedBox(height: 8),

    Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 10,
      ),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: Colors.white12,
        ),
      ),
      child: SelectableText(
        '/название команды',
        style: TextStyle(
          fontSize: 14,
          fontFamily: 'monospace',
          color: Theme.of(context).colorScheme.onSurface,
        ),
      ),
    ),

    SizedBox(height: 22),

    Text(
      '・заявки-на-увал',
      style: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
      ),
    ),

    SizedBox(height: 6),

    SelectableText(
      'Рассмотреть заявку → оформить увольнение в кадровом аудите → '
      'отправить запись об увольнении в ・заявки-на-увал '
      'с тегом @Помощник ГСК.',
      style: TextStyle(
        fontSize: 15,
        height: 1.5,
        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
      ),
    ),
  ],
),
    ],
  );
}
// ==========================================================
// ПАМЯТКА — ПРОВЕДЕНИЕ СОБЕСЕДОВАНИЯ
// ==========================================================

if (_selectedMemoFaction == 'Правительство' &&
    _selectedMemoDepartment == 'Управление кадров' &&
    _selectedMemoItem == 'Проведение собеседования') {
  return ListView(
    padding: const EdgeInsets.all(24),
    children: [
      Align(
        alignment: Alignment.centerLeft,
        child: TextButton.icon(
          onPressed: () {
            setState(() {
              _selectedMemoItem = null;
            });
          },
          icon: Icon(
            Icons.arrow_back,
            size: 18,
          ),
          label: Text(
            'Назад к памяткам отдела',
          ),
        ),
      ),

      SizedBox(height: 8),

      Text(
        'Проведение собеседования',
        style: TextStyle(
          fontSize: 28,
          fontWeight: FontWeight.w700,
        ),
      ),

      SizedBox(height: 8),

      Text(
        'Управление кадров · Правительство',
        style: TextStyle(
          color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.54),
          fontSize: 14,
        ),
      ),

      SizedBox(height: 20),

      Column(
  crossAxisAlignment: CrossAxisAlignment.start,
  children: [
    Text(
      '📋 ПАМЯТКА ПО ПРОВЕДЕНИЮ НАБОРА В ПРАВИТЕЛЬСТВО',
      style: TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.w800,
      ),
    ),

    SizedBox(height: 12),

    SelectableText(
      'Памятка для сотрудников, проводящих собеседования.\n\n'
      'Наша задача — не найти повод отказать кандидату, а проверить его '
      'соответствие требованиям Правительства и правилам проекта.',
      style: TextStyle(
        fontSize: 15,
        height: 1.5,
        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
      ),
    ),

    SizedBox(height: 24),

    Text(
      '1️⃣ НАЧАЛО СОБЕСЕДОВАНИЯ',
      style: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
      ),
    ),

    SizedBox(height: 8),

    SelectableText(
      'Перед началом:\n'
      '• представьтесь кандидату;\n'
      '• сообщите о начале собеседования;\n'
      '• попросите кандидата представиться;\n'
      '• уточните, почему он хочет работать в Правительстве;\n'
      '• попросите предоставить необходимые документы;\n'
      '• соблюдайте RP и субординацию.\n\n'
      '⚠️ Оценивайте не только ответы, но и поведение кандидата на протяжении всего собеседования.',
      style: TextStyle(
        fontSize: 15,
        height: 1.5,
        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
      ),
    ),

    SizedBox(height: 24),

    Text(
      '2️⃣ ПРОВЕРКА ПАСПОРТА',
      style: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
      ),
    ),

    SizedBox(height: 8),

    SelectableText(
      'Обязательно проверяем имя и фамилию кандидата.\n\n'
      '❌ Обращаем внимание на:\n'
      '• NonRP имя или фамилию;\n'
      '• никнейм вместо нормального имени;\n'
      '• очевидно шуточное имя;\n'
      '• имя или фамилию, не соответствующие RP-формату.\n\n'
      'Примеры:\n'
      '❌ Владимир Владимир\n'
      '❌ Пирожок Андрей\n'
      '❌ Владик Красавчик\n\n'
      '⚠️ Если имя вызывает сомнения — не принимайте решение наугад. '
      'Сначала уточните ситуацию через репорт.',
      style: TextStyle(
        fontSize: 15,
        height: 1.5,
        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
      ),
    ),

    SizedBox(height: 24),

    Text(
      '3️⃣ МЕДИЦИНСКИЕ СПРАВКИ И ДОКУМЕНТЫ',
      style: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
      ),
    ),

    SizedBox(height: 8),

    SelectableText(
      'Проверяем не только наличие документов, но и то, как кандидат их предоставляет и комментирует.\n\n'
      '✅ Нормально:\n'
      '«Передал медицинскую справку человеку напротив».\n\n'
      '❌ Неправильно:\n'
      '«Я её только что купил в F2».\n'
      '«У меня медкарта забагалась».\n'
      '«Нажмите на меня и посмотрите».\n'
      '«У меня справка не прогрузилась».\n\n'
      '⚠️ Использование информации об интерфейсе, игровых механиках и багах '
      'внутри IC-разговора может являться MG/NonRP.',
      style: TextStyle(
        fontSize: 15,
        height: 1.5,
        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
      ),
    ),

    SizedBox(height: 24),

    Text(
      '4️⃣ МОТИВАЦИЯ КАНДИДАТА',
      style: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
      ),
    ),

    SizedBox(height: 8),

    SelectableText(
      'Можно задать простые вопросы:\n'
      '• расскажите немного о себе;\n'
      '• почему хотите работать в Правительстве;\n'
      '• почему выбрали именно нашу организацию;\n'
      '• какие у вас сильные стороны;\n'
      '• какие слабые стороны;\n'
      '• как вы представляете свою работу в Правительстве.\n\n'
      'Здесь не нужно искать идеальный ответ. Главное — понять, способен ли '
      'кандидат нормально вести диалог и имеет ли RP-мотивацию.',
      style: TextStyle(
        fontSize: 15,
        height: 1.5,
        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
      ),
    ),

    SizedBox(height: 24),

    Text(
      '5️⃣ RP-ПОВЕДЕНИЕ НА СОБЕСЕДОВАНИИ',
      style: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
      ),
    ),

    SizedBox(height: 8),

    SelectableText(
      'Собеседование — полноценный RP-процесс.\n\n'
      'Для проверки понимания RP можно:\n'
      '• попросить кандидата отжаться;\n'
      '• попросить показать пальцем на предмет;\n'
      '• спросить, что находится над головой;\n'
      '• спросить, во что он одет;\n'
      '• использовать простые RP-отыгровки.\n\n'
      'Следим за:\n'
      '❌ прыжками по кабинету;\n'
      '❌ беспричинным бегом;\n'
      '❌ ударами сотрудников;\n'
      '❌ спамом анимациями;\n'
      '❌ постоянным перебиванием;\n'
      '❌ неадекватным поведением;\n'
      '❌ MG;\n'
      '❌ смешиванием IC и OOC;\n'
      '❌ игнорированием RP-процесса;\n'
      '❌ намеренными провокациями.\n\n'
      '⚠️ Одна случайная ошибка ≠ систематическое NonRP.',
      style: TextStyle(
        fontSize: 15,
        height: 1.5,
        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
      ),
    ),

    SizedBox(height: 24),

    Text(
      '6️⃣ ПРОВЕРКА MG / DM / RP',
      style: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
      ),
    ),

    SizedBox(height: 8),

    SelectableText(
      'Проверяйте знания так, чтобы кандидат не был вынужден сам произносить '
      'OOC-информацию в IC-разговоре.\n\n'
      'Можно использовать условные IC-обозначения и ситуационные вопросы.\n\n'
      'Например:\n'
      '• что вы сделаете, если узнаете информацию, которую ваш персонаж знать не может;\n'
      '• можно ли использовать информацию из спецсвязи непосредственно в IC-ситуации;\n'
      '• как поступить, если игровой интерфейс работает некорректно во время RP.',
      style: TextStyle(
        fontSize: 15,
        height: 1.5,
        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
      ),
    ),

    SizedBox(height: 24),

    Text(
      '7️⃣ ПРИМЕРЫ MG / NONRP',
      style: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
      ),
    ),

    SizedBox(height: 8),

    SelectableText(
      '❌ «У меня 1 уровень, к вам можно?»\n'
      '❌ «Мне админ сказал сюда прийти».\n'
      '❌ «У меня паспорт забагался».\n'
      '❌ «Я это на форуме прочитал».\n'
      '❌ «Нажмите на меня и посмотрите».\n'
      '❌ «У меня команда не работает».\n'
      '❌ «Я сейчас в Discord посмотрю».\n\n'
      'Кандидат должен понимать разницу между IC и OOC информацией.',
      style: TextStyle(
        fontSize: 15,
        height: 1.5,
        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
      ),
    ),

    SizedBox(height: 24),

    Text(
      '8️⃣ НЕ ПЫТАЕМСЯ «ЗАВАЛИТЬ» КАНДИДАТА',
      style: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
      ),
    ),

    SizedBox(height: 8),

    SelectableText(
      'Наша задача — проверить кандидата, а не специально добиться ошибки.\n\n'
      '✅ Можно:\n'
      '• задавать ситуационные вопросы;\n'
      '• проверять базовые правила;\n'
      '• проверять законодательство в разумных пределах;\n'
      '• уточнять ответы;\n'
      '• просить объяснить ответ своими словами.\n\n'
      '❌ Нельзя:\n'
      '• намеренно провоцировать нарушение;\n'
      '• придумывать несуществующие правила;\n'
      '• задавать вопросы только ради того, чтобы кандидат ошибся;\n'
      '• требовать знания информации, не относящейся к его работе.',
      style: TextStyle(
        fontSize: 15,
        height: 1.5,
        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
      ),
    ),

    SizedBox(height: 24),

    Text(
      '9️⃣ ОШИБКА И НАРУШЕНИЕ — НЕ ОДНО И ТО ЖЕ',
      style: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
      ),
    ),

    SizedBox(height: 8),

    SelectableText(
      '🟡 Ошибка в знаниях:\n'
      'кандидат неправильно ответил, перепутал формулировку или не полностью '
      'помнит статью, но понимает общий смысл.\n\n'
      '🔴 Нарушение правил:\n'
      'кандидат совершил MG/NonRP, оскорбляет, провоцирует, игнорирует RP-процесс '
      'или систематически нарушает правила.\n\n'
      '⚠️ Не каждую неправильную формулировку автоматически считаем нарушением.',
      style: TextStyle(
        fontSize: 15,
        height: 1.5,
        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
      ),
    ),

    SizedBox(height: 24),

    Text(
      '🔟 НЕ ПРИДУМЫВАЕМ ПРИЧИНЫ ДЛЯ ОТКАЗА',
      style: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
      ),
    ),

    SizedBox(height: 8),

    SelectableText(
      'Каждый отказ должен иметь понятную и объективную причину.\n\n'
      '❌ Нельзя:\n'
      '«Мне не понравился ваш голос».\n'
      '«Вы выглядите несерьёзно».\n'
      '«Мне кажется, вы нам не подходите».\n'
      '«Я таких кандидатов не принимаю».\n\n'
      '✅ Основание должно соответствовать действующим правилам и требованиям Правительства.',
      style: TextStyle(
        fontSize: 15,
        height: 1.5,
        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
      ),
    ),

    SizedBox(height: 24),

    Text(
      '1️⃣1️⃣ ЕСЛИ ВЫ НЕ УВЕРЕНЫ',
      style: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
      ),
    ),

    SizedBox(height: 8),

    SelectableText(
      'Если возникла спорная ситуация:\n'
      '• не спешите отказывать;\n'
      '• не придумывайте трактовку самостоятельно;\n'
      '• уточните информацию у старшего состава;\n'
      '• при необходимости обратитесь в репорт;\n'
      '• после уточнения продолжите собеседование.\n\n'
      'Лучше потратить минуту на проверку, чем необоснованно отказать человеку.',
      style: TextStyle(
        fontSize: 15,
        height: 1.5,
        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
      ),
    ),

    SizedBox(height: 24),

    Text(
      '1️⃣2️⃣ ЗАВЕРШЕНИЕ СОБЕСЕДОВАНИЯ',
      style: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
      ),
    ),

    SizedBox(height: 8),

    SelectableText(
      'Если кандидат прошёл собеседование:\n'
      '• сообщите ему о положительном результате;\n'
      '• предоставьте спецсвязь;\n'
      '• выдайте необходимые роли;\n'
      '• оформите трудовой договор;\n'
      '• внесите запись в кадровый аудит.\n\n'
      'Если кандидат не прошёл:\n'
      '• спокойно сообщите об отказе;\n'
      '• кратко объясните причину;\n'
      '• не вступайте в конфликт.',
      style: TextStyle(
        fontSize: 15,
        height: 1.5,
        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
      ),
    ),

    SizedBox(height: 24),

    Text(
      '🚨 ОСНОВНЫЕ ОШИБКИ КАДРОВИКА',
      style: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
      ),
    ),

    SizedBox(height: 8),

    SelectableText(
      '❌ Не заметил NonRP имя/фамилию.\n'
      '❌ Проигнорировал MG/NonRP кандидата.\n'
      '❌ Не проверил необходимые документы.\n'
      '❌ Подсказывал ответы.\n'
      '❌ Сам нарушал RP.\n'
      '❌ Придумал собственную причину отказа.\n'
      '❌ Принял кандидата без проверки знаний.\n'
      '❌ Намеренно пытался «завалить» кандидата.\n'
      '❌ Проявил предвзятость.\n'
      '❌ Не смог объяснить причину отказа.',
      style: TextStyle(
        fontSize: 15,
        height: 1.5,
        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
      ),
    ),

    SizedBox(height: 28),

    // ========================================================
    // БЫСТРАЯ ШПАРГАЛКА КАДРОВИКА
    // ========================================================
    Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.045),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.white30,
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '🧾 ВАШИ ДЕЙСТВИЯ НА СОБЕСЕДОВАНИИ',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
            ),
          ),

          SizedBox(height: 14),

          SelectableText(
            '1. Представьтесь\n'
            '«Здравствуйте, секретарь Управления кадров Правительства Имя Фамилия.»\n\n'
            '2. Начните собеседование\n'
            '«Сейчас я проведу с Вами собеседование для трудоустройства в Правительство.»\n\n'
            '3. Попросите кандидата рассказать о себе\n'
            '«Представьтесь, пожалуйста, и расскажите немного о себе.»\n\n'
            '4. Узнайте мотивацию\n'
            '«Что Вас мотивирует на трудоустройство в Правительство?»\n'
            '«Почему Вы выбрали именно нашу организацию?»\n\n'
            '5. Уточните сильные и слабые стороны\n'
            '«Назовите Ваши сильные стороны.»\n'
            '«Есть ли у Вас слабые стороны, над которыми Вы работаете?»\n\n'
            '6. Проверьте документы\n'
            '«Предоставьте, пожалуйста, паспорт, медицинские справки и водительское удостоверение.»\n\n'
            '7. Проверьте базовые знания и RP\n'
            '• задайте несколько вопросов по правилам;\n'
            '• попросите отжаться;\n'
            '• попросите показать на предмет;\n'
            '• спросите, что находится над головой;\n'
            '• можете использовать RP-отыгровки.\n\n'
            '8. Примите решение\n'
            'Если кандидат подходит — сообщите о прохождении собеседования.\n'
            'Если нет — спокойно и конкретно объясните причину отказа.\n\n'
            '9. После принятия\n'
'• предоставьте спецсвязь;\n'
'• выдайте роли;\n'
'• оформите трудовой договор;\n'
'• внесите запись в кадровый аудит.\n\n'

'10. Объясните дальнейшие действия\n'
'После принятия сотруднику необходимо объяснить, что он поступил на службу в Академию ФСО.\n\n'
'Сообщите ему, что необходимо ознакомиться с памяткой, которая находится в соответствующем разделе спец.связи.\n\n'
'Если сотрудник захочет перевестись в какое-либо Министерство, отдел или управление, ему необходимо отправить заявку в соответствующий раздел спец.связи.\n\n'
'После этого сообщите о необходимости получить удостоверение у Марии.\n\n'
'Также объясните, что форму можно получить в гардеробе в холле Правительства.\n'
'Необходимая форма — чёрная, с кепкой.',
            style: TextStyle(
              fontSize: 15,
              height: 1.55,
              color: Theme.of(context).colorScheme.onSurface,
            ),
          ),
        ],
      ),
    ),

    SizedBox(height: 20),

    Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: Colors.white.withValues(alpha: 0.035),
        border: Border.all(
          color: Colors.white12,
        ),
      ),
      child: Text(
        '📌 Главный принцип: мы не ищем повод отказать кандидату. '
        'Мы проверяем, соответствует ли он установленным требованиям.',
        style: TextStyle(
          fontSize: 14,
          height: 1.5,
          fontWeight: FontWeight.w600,
          color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
        ),
      ),
    ),
  ],
),
    ],
  );
}
// ==========================================================
// ПАМЯТКА — СИСТЕМА ПОВЫШЕНИЯ УПРАВЛЕНИЯ КАДРОВ
// ==========================================================

if (_selectedMemoFaction == 'Правительство' &&
    _selectedMemoDepartment == 'Управление кадров' &&
    _selectedMemoItem == 'Система повышения') {
  return ListView(
    padding: const EdgeInsets.all(24),
    children: [
      // ------------------------------------------------------
      // КНОПКА НАЗАД
      // ------------------------------------------------------
      Align(
        alignment: Alignment.centerLeft,
        child: TextButton.icon(
          onPressed: () {
            setState(() {
              _selectedMemoItem = null;
            });
          },
          icon: Icon(
            Icons.arrow_back,
            size: 18,
          ),
          label: Text(
            'Назад к памяткам отдела',
          ),
        ),
      ),

      SizedBox(height: 8),

      Text(
        'Система повышения',
        style: TextStyle(
          fontSize: 28,
          fontWeight: FontWeight.w700,
        ),
      ),

      SizedBox(height: 8),

      Text(
        'Управление кадров · Правительство',
        style: TextStyle(
          color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.54),
          fontSize: 14,
        ),
      ),

      SizedBox(height: 24),

      // ======================================================
      // СТАЖЁР → СЕКРЕТАРЬ
      // ======================================================
      Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.035),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: Colors.white24,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'СТАЖЁР → СЕКРЕТАРЬ',
              style: TextStyle(
                fontSize: 19,
                fontWeight: FontWeight.w800,
              ),
            ),

            SizedBox(height: 14),

            Text(
              'Сдать экзамен по знанию:',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w700,
              ),
            ),

            SizedBox(height: 10),

            // --------------------------------------------------
            // ВНУТРЕННЯЯ ССЫЛКА — ОБЯЗАННОСТИ ОТДЕЛА
            // --------------------------------------------------
            InkWell(
              onTap: () {
                setState(() {
                  _selectedMemoItem = 'Обязанности отдела';
                });
              },
              borderRadius: BorderRadius.circular(8),
              child: Padding(
                padding: EdgeInsets.symmetric(
                  vertical: 7,
                  horizontal: 4,
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.assignment_outlined,
                      size: 18,
                      color: Colors.lightBlueAccent,
                    ),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Обязанности отдела',
                        style: TextStyle(
                          fontSize: 15,
                          color: Colors.lightBlueAccent,
                          decoration: TextDecoration.underline,
                          decorationColor: Colors.lightBlueAccent,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // --------------------------------------------------
            // ВНУТРЕННЯЯ ССЫЛКА — ПРОВЕДЕНИЕ СОБЕСЕДОВАНИЯ
            // --------------------------------------------------
            InkWell(
              onTap: () {
                setState(() {
                  _selectedMemoItem = 'Проведение собеседования';
                });
              },
              borderRadius: BorderRadius.circular(8),
              child: Padding(
                padding: EdgeInsets.symmetric(
                  vertical: 7,
                  horizontal: 4,
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.record_voice_over_outlined,
                      size: 18,
                      color: Colors.lightBlueAccent,
                    ),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Проведение собеседования',
                        style: TextStyle(
                          fontSize: 15,
                          color: Colors.lightBlueAccent,
                          decoration: TextDecoration.underline,
                          decorationColor: Colors.lightBlueAccent,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            SizedBox(height: 6),

            // ==================================================
            // РАСКРЫВАЮЩАЯСЯ ПАМЯТКА ДЛЯ МЛАДШЕГО СОСТАВА
            // ==================================================
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: Colors.white24,
                ),
              ),
              child: ExpansionTile(
                tilePadding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 2,
                ),
                childrenPadding: const EdgeInsets.fromLTRB(
                  16,
                  0,
                  16,
                  16,
                ),
                leading: Icon(
                  Icons.menu_book_outlined,
                  color: Colors.lightBlueAccent,
                ),
                title: Text(
                  'Памятка для младшего состава',
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: Colors.lightBlueAccent,
                  ),
                ),
                children: [
                  SelectableText(
                    'Если вы сомневаетесь в имени/фамилии кандидата, '
                    'самостоятельно напишите в /report и уточните, допустимо ли '
                    'данное имя/фамилия.\n\n'
                    'После ответа администрации продолжайте приём.',
                    style: TextStyle(
                      fontSize: 14,
                      height: 1.5,
                      color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
                    ),
                  ),

                  SizedBox(height: 16),

                  Text(
                    'Правильно составленный кадровый аудит:',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                    ),
                  ),

                  SizedBox(height: 10),

                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.18),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: Colors.white12,
                      ),
                    ),
                    child: SelectableText(
                      '/увольнение пользователь ранг причина\n\n'
                      '/повышение пользователь был стал причина\n\n'
                      '/принятие пользователь ранг причина\n\n'
                      '/восстановление пользователь ранг причина',
                      style: TextStyle(
                        fontSize: 14,
                        height: 1.5,
                        fontFamily: 'monospace',
                        color: Theme.of(context).colorScheme.onSurface,
                      ),
                    ),
                  ),

                  SizedBox(height: 14),

                  
                ],
              ),
            ),

            SizedBox(height: 10),

            // --------------------------------------------------
            // ФКЗ О ПРАВИТЕЛЬСТВЕ
            // --------------------------------------------------
            _buildMemoLink(
              title: 'ФКЗ «О Правительстве»',
              url:
                  'https://forum.russia.online/threads/federal-nyi-konstitutsionnyi-zakon-no-1-fkz-o-pravitel-stve.1185/',
            ),

            SizedBox(height: 14),

            Text(
              'Экзамен принимается старшим составом или старшими секретарями.',
              style: TextStyle(
                fontSize: 14,
                height: 1.5,
                color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
              ),
            ),

            SizedBox(height: 14),

            Text(
              'Запросы на проведение экзамена',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w700,
              ),
            ),

            SizedBox(height: 18),

            SelectableText(
              '• Получить удостоверение.',
              style: TextStyle(
                fontSize: 15,
                height: 1.5,
                color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
              ),
            ),

            SizedBox(height: 12),

            Text(
              'Дежурство в холле Правительства — 1 час',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w700,
              ),
            ),

            SizedBox(height: 8),

            SelectableText(
              'Необходимо предоставить отчёт из 5 скриншотов с HUD:\n\n'
              '• начало дежурства;\n'
              '• через 15 минут;\n'
              '• через 30 минут;\n'
              '• через 45 минут;\n'
              '• конец дежурства.\n\n'
              'Во время дежурства необходимо делать отпись в рацию:\n\n'
              '«Собеседование в Правительство ведётся на 1 этаже '
              'в кабинете специалистов».\n\n'
              'На скриншоте должен быть полный экран и телефон в руке, '
              'на котором чётко видно время.',
              style: TextStyle(
                fontSize: 14,
                height: 1.55,
                color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
              ),
            ),
          ],
        ),
      ),

      SizedBox(height: 20),

      // ======================================================
      // СЕКРЕТАРЬ → СТАРШИЙ СЕКРЕТАРЬ
      // ======================================================
      Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.035),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: Colors.white24,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'СЕКРЕТАРЬ → СТАРШИЙ СЕКРЕТАРЬ',
              style: TextStyle(
                fontSize: 19,
                fontWeight: FontWeight.w800,
              ),
            ),

            SizedBox(height: 14),

            SelectableText(
              'Для повышения необходимо:\n\n'
              '• находиться в отделе 5 дней и более;\n\n'
              '• набрать с момента назначения на 8 ранг '
              '80 кадровых действий;\n\n'
              '• вместо части кадровых действий можно использовать подачи GNews;\n\n'
              '• каждая подача GNews считается за 5 кадровых действий.',
              style: TextStyle(
                fontSize: 15,
                height: 1.55,
                color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
              ),
            ),

            SizedBox(height: 14),

            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.045),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: Colors.white12,
                ),
              ),
              child: SelectableText(
                'Пример:\n'
                '40 кадровых действий + 8 подач GNews = 80 кадровых.\n\n'
                'Подачи должны быть отправлены в соответствующий канал '
                'с тегом руководства и могут использоваться в отчёте.',
                style: TextStyle(
                  fontSize: 14,
                  height: 1.5,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
              ),
            ),

            SizedBox(height: 14),

            // --------------------------------------------------
            // ТРУДОВОЙ КОДЕКС
            // --------------------------------------------------
            _buildMemoLink(
              title: 'Сдать экзамен по Трудовому кодексу',
              url:
                  'https://forum.russia.online/threads/trudovoi-kodeks.1395/',
            ),

            SizedBox(height: 8),

            // --------------------------------------------------
            // КАНАЛ ОТЧЁТОВ
            // --------------------------------------------------
            _buildMemoLink(
              title: 'Все отчёты отправлять сюда',
              url:
                  'https://discord.com/channels/1538939600549191830/1541840207245222038',
            ),
          ],
        ),
      ),

      SizedBox(height: 20),

      // ======================================================
      // КОРОТКОЕ НАПОМИНАНИЕ
      // ======================================================
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.03),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: Colors.white12,
          ),
        ),
        child: Text(
          '📌 Перед подачей отчёта на повышение убедитесь, '
          'что выполнены все требования для вашего текущего ранга.',
          style: TextStyle(
            fontSize: 14,
            height: 1.5,
            fontWeight: FontWeight.w600,
            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
          ),
        ),
      ),
    ],
  );
}
// ==========================================================
// ПАМЯТКА — БЫСТРЫЕ КОМАНДЫ
// ==========================================================

if (_selectedMemoFaction == 'Правительство' &&
    _selectedMemoDepartment == 'Управление кадров' &&
    _selectedMemoItem == 'Быстрые команды') {

  // ========================================================
  // БЫСТРЫЕ КОМАНДЫ — ОДНА КОПИРУЕМАЯ КОМАНДА
  // ========================================================
  Widget quickCommandBox({
    required String command,
    String? title,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.045),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: Colors.white12,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (title != null) ...[
            Text(
              title,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.54),
              ),
            ),
            SizedBox(height: 8),
          ],

          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: SelectableText(
                  command,
                  style: TextStyle(
                    fontSize: 14,
                    height: 1.5,
                    fontFamily: 'monospace',
                    color: Theme.of(context).colorScheme.onSurface,
                  ),
                ),
              ),

              SizedBox(width: 8),

              IconButton(
                tooltip: 'Скопировать',
                onPressed: () async {
                  await Clipboard.setData(
                    ClipboardData(text: command),
                  );

                  if (!mounted) return;

                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Скопировано'),
                      duration: Duration(seconds: 1),
                    ),
                  );
                },
                icon: Icon(
                  Icons.copy,
                  size: 18,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  return ListView(
    padding: const EdgeInsets.all(24),
    children: [
      // ------------------------------------------------------
      // КНОПКА НАЗАД
      // ------------------------------------------------------
      Align(
        alignment: Alignment.centerLeft,
        child: TextButton.icon(
          onPressed: () {
            setState(() {
              _selectedMemoItem = null;
            });
          },
          icon: Icon(
            Icons.arrow_back,
            size: 18,
          ),
          label: Text(
            'Назад к памяткам отдела',
          ),
        ),
      ),

      SizedBox(height: 8),

      Text(
        'Быстрые команды',
        style: TextStyle(
          fontSize: 28,
          fontWeight: FontWeight.w700,
        ),
      ),

      SizedBox(height: 8),

      Text(
        'Управление кадров · Правительство',
        style: TextStyle(
          color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.54),
          fontSize: 14,
        ),
      ),

      SizedBox(height: 24),

      // ======================================================
      // 1. ПОДАЧА ГОСУДАРСТВЕННОЙ ВОЛНЫ
      // ======================================================
      Text(
        '1. Подача гос.волны',
        style: TextStyle(
          fontSize: 19,
          fontWeight: FontWeight.w800,
        ),
      ),

      SizedBox(height: 14),

      Text(
        'Запрос свободной волны',
        style: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w700,
        ),
      ),

      SizedBox(height: 8),

      quickCommandBox(
        command:
            '/dep ко всем: Свободна ли волна на 00:15/00:25/00:35?',
      ),

      SizedBox(height: 10),

      SelectableText(
        '⏱ Ждём 2 минуты.',
        style: TextStyle(
          fontSize: 14,
          height: 1.5,
          color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
        ),
      ),

      SizedBox(height: 10),

      quickCommandBox(
        title: 'Повторяем запрос',
        command:
            '/dep ко всем: Свободна ли волна на 00:15/00:25/00:35? *Повторяя*',
      ),

      SizedBox(height: 10),

      SelectableText(
        'Если ответ не поступил — занимаем государственную волну.',
        style: TextStyle(
          fontSize: 14,
          height: 1.5,
          color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
        ),
      ),

      SizedBox(height: 10),

      quickCommandBox(
        command:
            '/dep ко всем: Не услышал ответа, занял гос волну на 00:15/00:25/00:35.',
      ),

      SizedBox(height: 20),

      // ------------------------------------------------------
      // ПЕРВАЯ GNEWS — НАЧАЛО НАБОРА
      // ------------------------------------------------------
      Text(
        'Начало набора',
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w700,
        ),
      ),

      SizedBox(height: 8),

      quickCommandBox(
        title: 'Первая GNews',
        command:
            '/gnews Уважаемые жители г. Москвы, в данный момент началось собеседование в Правительство РО. Не упустите шанс пополнить ряды государственных служащих. Набор идет в: ФСО, Управление кадров, Министерство Культуры, а также Коллегию Адвокатов. При себе требуется иметь медицинскую справку. Собеседование проходит в здании Тверского районного суда, обозначенного на городских картах «Правительство». С уважением, Управление кадров Правительства РО.',
      ),

      SizedBox(height: 16),

      Text(
        'Через 10 минут',
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w700,
        ),
      ),

      SizedBox(height: 8),

      quickCommandBox(
        title: 'Вторая GNews',
        command:
            '/gnews Уважаемые жители г. Москвы, в данный момент проводится собеседование в Правительство РО. Не упустите шанс пополнить ряды государственных служащих. Набор идет в: ФСО, Управление кадров, Министерство Культуры, а также Коллегию Адвокатов. При себе требуется иметь медицинскую справку. Собеседование проходит в здании Тверского районного суда, обозначенного на городских картах «Правительство». С уважением, Управление кадров Правительства РО.',
      ),

      SizedBox(height: 16),

      Text(
        'Ещё через 10 минут — конец набора',
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w700,
        ),
      ),

      SizedBox(height: 8),

      quickCommandBox(
        title: 'Третья GNews',
        command:
            '/gnews Уважаемые жители г. Москвы, собеседование в Правительство РО закончилось. Если вы упустили свой шанс пополнить ряды государственных служащих. А именно в: ФСО, Управление кадров, Министерство Культуры, а также Коллегию Адвокатов. Заполняйте электронные заявки на портале Округа. С уважением, Управление кадров Правительства РО.',
      ),

      SizedBox(height: 16),

      Text(
        'После опубликования трёх GNews освобождаем волну:',
        style: TextStyle(
          fontSize: 14,
          height: 1.5,
          color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
        ),
      ),

      SizedBox(height: 8),

      quickCommandBox(
        command: '/dep ко всем: Освободил гос. волну.',
      ),

      SizedBox(height: 32),

      // ======================================================
      // 2. RP-ОТЫГРОВКИ
      // ======================================================
      Text(
        '2. RP-отыгровки',
        style: TextStyle(
          fontSize: 19,
          fontWeight: FontWeight.w800,
        ),
      ),

      SizedBox(height: 8),

      Text(
        'Использовать одну или несколько при проверке кандидата.',
        style: TextStyle(
          fontSize: 14,
          color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.54),
        ),
      ),

      SizedBox(height: 14),

      quickCommandBox(
        command:
            '/do Около клавиатуры лежит фиолетовая папка с документами.',
      ),

      SizedBox(height: 10),

      quickCommandBox(
        command:
            '/me достал из кармана скрепку.\n'
            '/do В руках красная скрепка.\n'
            '/me убрал скрепку в карман.',
      ),

      SizedBox(height: 10),

      quickCommandBox(
        command:
            '/do В календаре маркер отстаёт на один день.',
      ),

      SizedBox(height: 10),

      quickCommandBox(
        command:
            '/do На компьютере запущена "Косынка".',
      ),

      SizedBox(height: 32),

      // ======================================================
      // 3. ШЕПНУТЬ DISCORD
      // ======================================================
      Text(
        '3. Шепнуть свой Discord',
        style: TextStyle(
          fontSize: 19,
          fontWeight: FontWeight.w800,
        ),
      ),

      SizedBox(height: 14),

      quickCommandBox(
        command: '/w 000 5041nskiy',
      ),

      SizedBox(height: 32),

      // ======================================================
      // 4. СООБЩЕНИЕ В ЛИЧКУ DISCORD
      // ======================================================
      Text(
        '4. Сообщение в личку Discord',
        style: TextStyle(
          fontSize: 19,
          fontWeight: FontWeight.w800,
        ),
      ),

      SizedBox(height: 14),

    

      SizedBox(height: 12),

      quickCommandBox(
        title: 'Сообщение сотруднику',
        command:
            'https://discord.gg/GYPcmc7NdA\n\n'
            'Чтобы получить роль требуется никнейм на сервере по форме:\n\n'
            'Стажер | Имя Фамилия | Ваш статик\n\n'
            'Писать в получение роли.',
      ),

      SizedBox(height: 20),
    ],
  );
}
// ==========================================================
// ПАМЯТКА — ОСНОВНЫЕ ССЫЛКИ
// ==========================================================

if (_selectedMemoFaction == 'Правительство' &&
    _selectedMemoDepartment == 'Управление кадров' &&
    _selectedMemoItem == 'Основные ссылки') {

  // ========================================================
  // ОСНОВНЫЕ ССЫЛКИ — ОДНА КЛИКАБЕЛЬНАЯ И КОПИРУЕМАЯ ССЫЛКА
  // ========================================================
  Widget linkBox({
    required String title,
    required String url,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.045),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: Colors.white12,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: InkWell(
              onTap: () {
                _openMemoLink(url);
              },
              borderRadius: BorderRadius.circular(8),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  vertical: 4,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),

                    SizedBox(height: 6),

                    Text(
                      url,
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.lightBlueAccent,
                        decoration: TextDecoration.underline,
                        decorationColor: Colors.lightBlueAccent,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          SizedBox(width: 10),

          IconButton(
            tooltip: 'Скопировать ссылку',
            onPressed: () async {
              await Clipboard.setData(
                ClipboardData(text: url),
              );

              if (!mounted) return;

              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Ссылка скопирована'),
                  duration: Duration(seconds: 1),
                ),
              );
            },
            icon: Icon(
              Icons.copy,
              size: 18,
            ),
          ),
        ],
      ),
    );
  }

  return ListView(
    padding: const EdgeInsets.all(24),
    children: [
      // ------------------------------------------------------
      // НАЗАД
      // ------------------------------------------------------
      Align(
        alignment: Alignment.centerLeft,
        child: TextButton.icon(
          onPressed: () {
            setState(() {
              _selectedMemoItem = null;
            });
          },
          icon: Icon(
            Icons.arrow_back,
            size: 18,
          ),
          label: Text(
            'Назад к памяткам отдела',
          ),
        ),
      ),

      SizedBox(height: 8),

      Text(
        'Основные ссылки',
        style: TextStyle(
          fontSize: 28,
          fontWeight: FontWeight.w700,
        ),
      ),

      SizedBox(height: 8),

      Text(
        'Управление кадров · Правительство',
        style: TextStyle(
          color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.54),
          fontSize: 14,
        ),
      ),

      SizedBox(height: 24),

      // ======================================================
      // DISCORD
      // ======================================================
      linkBox(
        title: 'Discord',
        url: 'https://discord.gg/GYPcmc7NdA',
      ),

      SizedBox(height: 12),

      // ======================================================
      // ЗАКОНОДАТЕЛЬСТВО
      // ======================================================
      linkBox(
        title: 'Трудовой кодекс',
        url:
            'https://forum.russia.online/threads/trudovoi-kodeks.1395/',
      ),

      SizedBox(height: 12),

      linkBox(
        title: 'ФКЗ «О Правительстве»',
        url:
            'https://forum.russia.online/threads/federal-nyi-konstitutsionnyi-zakon-no-1-fkz-o-pravitel-stve.1185/',
      ),

      SizedBox(height: 12),

      // ======================================================
      // КАДРОВЫЕ КАНАЛЫ
      // ======================================================
      linkBox(
        title: 'Кадровый аудит',
        url:
            'https://discord.com/channels/1538939600549191830/1538939604168867901',
      ),

      SizedBox(height: 12),

      linkBox(
        title: 'Выдача ролей',
        url:
            'https://discord.com/channels/1538939600549191830/1538939603606573070',
      ),

      SizedBox(height: 12),

      linkBox(
        title: 'Заявки на увал',
        url:
            'https://discord.com/channels/1538939600549191830/1540120233614901280',
      ),

      SizedBox(height: 12),

      linkBox(
        title: 'Отчёт о проделанной работе',
        url:
            'https://discord.com/channels/1538939600549191830/1540483241277128815',
      ),

      SizedBox(height: 12),

      linkBox(
        title: 'Запрос на экзамен',
        url:
            'https://discord.com/channels/1538939600549191830/1543987051362254948',
      ),

      SizedBox(height: 12),

      linkBox(
        title: 'Отчёты на повышение',
        url:
            'https://discord.com/channels/1538939600549191830/1541840207245222038',
      ),

      SizedBox(height: 20),
    ],
  );
}
    // Открытый обычный пункт памятки Управления кадров.
    if (_selectedMemoFaction == 'Правительство' &&
        _selectedMemoDepartment == 'Управление кадров' &&
        _selectedMemoItem != null) {
      return ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: TextButton.icon(
              onPressed: () {
                setState(() {
                  _selectedMemoItem = null;
                });
              },
              icon: Icon(
                Icons.arrow_back,
                size: 18,
              ),
              label: Text(
                'Назад к памяткам отдела',
              ),
            ),
          ),

          SizedBox(height: 8),

          Text(
            _selectedMemoItem!,
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.w700,
            ),
          ),

          SizedBox(height: 8),

          Text(
            'Управление кадров · Правительство',
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.54),
              fontSize: 14,
            ),
          ),

          SizedBox(height: 20),

          Text(
            'Содержимое этого раздела добавим следующим шагом.',
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.70),
              fontSize: 14,
            ),
          ),
        ],
      );
    }

    // Управление кадров — список его памяток.
    if (_selectedMemoFaction == 'Правительство' &&
        _selectedMemoDepartment == 'Управление кадров') {
      return ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: TextButton.icon(
              onPressed: () {
                setState(() {
                  _selectedMemoDepartment = null;
                  _selectedMemoItem = null;
                });
              },
              icon: Icon(
                Icons.arrow_back,
                size: 18,
              ),
              label: Text(
                'Назад к отделам',
              ),
            ),
          ),

          SizedBox(height: 8),

          Text(
            'Управление кадров',
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.w700,
            ),
          ),

          SizedBox(height: 8),

          Text(
            'Правительство',
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.54),
              fontSize: 14,
            ),
          ),

          SizedBox(height: 20),

          _buildMemoItemTile(
            icon: Icons.assignment_outlined,
            title: 'Обязанности отдела',
          ),

          SizedBox(height: 10),

          _buildMemoItemTile(
            icon: Icons.record_voice_over_outlined,
            title: 'Проведение собеседования',
          ),

          SizedBox(height: 10),

          _buildMemoItemTile(
  icon: Icons.trending_up_outlined,
  title: 'Система повышения',
),

SizedBox(height: 10),

          _buildMemoItemTile(
            icon: Icons.bolt_outlined,
            title: 'Быстрые команды',
          ),

          SizedBox(height: 10),

          _buildMemoItemTile(
            icon: Icons.link_outlined,
            title: 'Основные ссылки',
          ),

          SizedBox(height: 10),

          _buildMemoItemTile(
            icon: Icons.calculate_outlined,
            title: 'Калькулятор недельного отчёта',
          ),

        ],
      );
    }

    // Правительство — список отделов.
    if (_selectedMemoFaction == 'Правительство') {
      return ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: TextButton.icon(
              onPressed: () {
                setState(() {
                  _selectedMemoFaction = null;
                  _selectedMemoDepartment = null;
                  _selectedMemoItem = null;
                });
              },
              icon: Icon(
                Icons.arrow_back,
                size: 18,
              ),
              label: Text(
                'Назад к списку фракций',
              ),
            ),
          ),

          SizedBox(height: 8),

          Text(
            'Правительство',
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.w700,
            ),
          ),

          SizedBox(height: 8),

          Text(
            'Выберите отдел',
            style: TextStyle(
              color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.54),
              fontSize: 14,
            ),
          ),

          SizedBox(height: 20),

          _buildMemoDepartmentTile(
            icon: Icons.dashboard_outlined,
            title: 'Общая',
          ),

          SizedBox(height: 10),

          _buildMemoDepartmentTile(
            icon: Icons.groups_outlined,
            title: 'Управление кадров',
          ),

          SizedBox(height: 10),

          _buildMemoDepartmentTile(
            icon: Icons.shield_outlined,
            title: 'ФСО',
          ),

          SizedBox(height: 10),

          _buildMemoDepartmentTile(
            icon: Icons.gavel_outlined,
            title: 'Судебная власть',
          ),

          SizedBox(height: 10),

          _buildMemoDepartmentTile(
            icon: Icons.balance_outlined,
            title: 'Адвокатура',
          ),

          SizedBox(height: 10),

          _buildMemoDepartmentTile(
            icon: Icons.medical_services_outlined,
            title: 'Мин. Здрав.',
          ),

          SizedBox(height: 10),

          _buildMemoDepartmentTile(
            icon: Icons.account_balance_wallet_outlined,
            title: 'Мин. Фин.',
          ),

          SizedBox(height: 10),

          _buildMemoDepartmentTile(
            icon: Icons.local_police_outlined,
            title: 'МВД',
          ),
        ],
      );
    }

    // Корневой уровень памяток — выбор фракции.
    return ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Text(
          'Памятки',
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.w700,
          ),
        ),

        SizedBox(height: 8),

        Text(
          'Выберите фракцию',
          style: TextStyle(
            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.54),
            fontSize: 14,
          ),
        ),

        SizedBox(height: 20),

        _buildMemoFactionTile(
          icon: Icons.account_balance_outlined,
          title: 'Правительство',
        ),

        SizedBox(height: 10),

        _buildMemoFactionTile(
          icon: Icons.local_hospital_outlined,
          title: 'Больница',
        ),

        SizedBox(height: 10),

        _buildMemoFactionTile(
          icon: Icons.local_police_outlined,
          title: 'МВД',
        ),

        SizedBox(height: 10),

        _buildMemoFactionTile(
          icon: Icons.traffic_outlined,
          title: 'ГИБДД',
        ),

        SizedBox(height: 10),

        _buildMemoFactionTile(
          icon: Icons.military_tech_outlined,
          title: 'АРМИЯ',
        ),

        SizedBox(height: 10),

        _buildMemoFactionTile(
          icon: Icons.security_outlined,
          title: 'ФСБ',
        ),

        SizedBox(height: 10),

        _buildMemoFactionTile(
          icon: Icons.balance_outlined,
          title: 'Адвокаты',
        ),
      ],
    );
  }


  @override
  Widget build(BuildContext context) {
    return _buildMemosPage();
  }
}
